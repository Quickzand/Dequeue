### Instructions

1. Run `yarn compile`
2. Open `index.html`

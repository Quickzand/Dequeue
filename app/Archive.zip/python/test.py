import os

os.popen("notepad.exe")

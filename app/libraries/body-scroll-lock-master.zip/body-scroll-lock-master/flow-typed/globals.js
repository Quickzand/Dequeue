declare var document: any;
